

struct student {
	char *name;
	int student_id;
	int scores[5];
	double gpa;
};

struct course {
	char *name;
	int num;
	char *instructor;
};

int main() {
	struct student Bob  = { "Ankunda Kiremire", 69420, {90, 92, 100, 99, 105}    , 3.5 };
	struct student Joe = { "Andrey Timofeyev", 1337 , {100, 120, 100, 140, 9001} , 6.0 };
	struct student Sue = { "Gene Gourd"      , 130  , {0, 0, 69, 0, 0}           , 1.9 };

	struct course wasteoftime = { "Intro to British Literature", 42069    , "are you even reading this" };
	struct course coolstuff   = { "Systems Programming"        , 123456789, "timmy feyev" };
	struct course easyA       = { "Data Structures"            , 11111111 , "gourd_and_savior" };
}
